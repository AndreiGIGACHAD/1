package com.example23.demo_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
